sap.ui.define(["sap/suite/ui/generic/template/lib/AppComponent"], function(AppComponent) {
    return AppComponent.extend("smcl.sf.wm.zz1wminbdq1.zz1wminbdq1.Component", {
        metadata: {
            manifest: "json"
        }
    });
});
